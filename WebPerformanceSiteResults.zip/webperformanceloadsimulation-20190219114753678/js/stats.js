var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "181807",
        "ok": "25078",
        "ko": "156729"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "4854"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "26975",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "9202",
        "ok": "1535",
        "ko": "10429"
    },
    "standardDeviation": {
        "total": "3344",
        "ok": "2593",
        "ko": "991"
    },
    "percentiles1": {
        "total": "10017",
        "ok": "208",
        "ko": "10046"
    },
    "percentiles2": {
        "total": "10231",
        "ok": "1848",
        "ko": "10301"
    },
    "percentiles3": {
        "total": "13218",
        "ok": "7534",
        "ko": "13231"
    },
    "percentiles4": {
        "total": "13577",
        "ok": "11011",
        "ko": "13629"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 17964,
        "percentage": 10
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 450,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 6664,
        "percentage": 4
    },
    "group4": {
        "name": "failed",
        "count": 156729,
        "percentage": 86
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1196.099",
        "ok": "164.987",
        "ko": "1031.112"
    }
},
contents: {
"req_main-page-95658": {
        type: "REQUEST",
        name: "Main Page",
path: "Main Page",
pathFormatted: "req_main-page-95658",
stats: {
    "name": "Main Page",
    "numberOfRequests": {
        "total": "15000",
        "ok": "139",
        "ko": "14861"
    },
    "minResponseTime": {
        "total": "1566",
        "ok": "1566",
        "ko": "9130"
    },
    "maxResponseTime": {
        "total": "18429",
        "ok": "16843",
        "ko": "18429"
    },
    "meanResponseTime": {
        "total": "11053",
        "ok": "7711",
        "ko": "11085"
    },
    "standardDeviation": {
        "total": "1657",
        "ok": "3573",
        "ko": "1596"
    },
    "percentiles1": {
        "total": "10281",
        "ok": "8242",
        "ko": "10284"
    },
    "percentiles2": {
        "total": "11411",
        "ok": "10334",
        "ko": "11414"
    },
    "percentiles3": {
        "total": "13497",
        "ok": "12097",
        "ko": "13498"
    },
    "percentiles4": {
        "total": "17617",
        "ok": "16354",
        "ko": "17620"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 139,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 14861,
        "percentage": 99
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "0.914",
        "ko": "97.77"
    }
}
    },"req_methodology-png-b165b": {
        type: "REQUEST",
        name: "methodology.png",
path: "methodology.png",
pathFormatted: "req_methodology-png-b165b",
stats: {
    "name": "methodology.png",
    "numberOfRequests": {
        "total": "139",
        "ok": "1",
        "ko": "138"
    },
    "minResponseTime": {
        "total": "10000",
        "ok": "11793",
        "ko": "10000"
    },
    "maxResponseTime": {
        "total": "17765",
        "ok": "11793",
        "ko": "17765"
    },
    "meanResponseTime": {
        "total": "11079",
        "ok": "11793",
        "ko": "11074"
    },
    "standardDeviation": {
        "total": "1670",
        "ok": "0",
        "ko": "1675"
    },
    "percentiles1": {
        "total": "10195",
        "ok": "11793",
        "ko": "10195"
    },
    "percentiles2": {
        "total": "12500",
        "ok": "11793",
        "ko": "12754"
    },
    "percentiles3": {
        "total": "13554",
        "ok": "11793",
        "ko": "13555"
    },
    "percentiles4": {
        "total": "17563",
        "ok": "11793",
        "ko": "17566"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 138,
        "percentage": 99
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.007",
        "ko": "0.908"
    }
}
    },"req_fast-png-e3425": {
        type: "REQUEST",
        name: "fast.png",
path: "fast.png",
pathFormatted: "req_fast-png-e3425",
stats: {
    "name": "fast.png",
    "numberOfRequests": {
        "total": "139",
        "ok": "2",
        "ko": "137"
    },
    "minResponseTime": {
        "total": "7944",
        "ok": "7944",
        "ko": "9750"
    },
    "maxResponseTime": {
        "total": "17765",
        "ok": "10099",
        "ko": "17765"
    },
    "meanResponseTime": {
        "total": "11028",
        "ok": "9022",
        "ko": "11057"
    },
    "standardDeviation": {
        "total": "1529",
        "ok": "1078",
        "ko": "1515"
    },
    "percentiles1": {
        "total": "10200",
        "ok": "9022",
        "ko": "10211"
    },
    "percentiles2": {
        "total": "13208",
        "ok": "9560",
        "ko": "13213"
    },
    "percentiles3": {
        "total": "13415",
        "ok": "9991",
        "ko": "13419"
    },
    "percentiles4": {
        "total": "13716",
        "ok": "10077",
        "ko": "13720"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 137,
        "percentage": 99
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.013",
        "ko": "0.901"
    }
}
    },"req_engineer-png-1bce4": {
        type: "REQUEST",
        name: "engineer.png",
path: "engineer.png",
pathFormatted: "req_engineer-png-1bce4",
stats: {
    "name": "engineer.png",
    "numberOfRequests": {
        "total": "139",
        "ok": "3",
        "ko": "136"
    },
    "minResponseTime": {
        "total": "7905",
        "ok": "7905",
        "ko": "10000"
    },
    "maxResponseTime": {
        "total": "17765",
        "ok": "10099",
        "ko": "17765"
    },
    "meanResponseTime": {
        "total": "10948",
        "ok": "9330",
        "ko": "10984"
    },
    "standardDeviation": {
        "total": "1496",
        "ok": "1009",
        "ko": "1485"
    },
    "percentiles1": {
        "total": "10191",
        "ok": "9986",
        "ko": "10195"
    },
    "percentiles2": {
        "total": "11379",
        "ok": "10043",
        "ko": "11391"
    },
    "percentiles3": {
        "total": "13395",
        "ok": "10088",
        "ko": "13398"
    },
    "percentiles4": {
        "total": "13714",
        "ok": "10097",
        "ko": "13721"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 136,
        "percentage": 98
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.02",
        "ko": "0.895"
    }
}
    },"req_style-css-da232": {
        type: "REQUEST",
        name: "style.css",
path: "style.css",
pathFormatted: "req_style-css-da232",
stats: {
    "name": "style.css",
    "numberOfRequests": {
        "total": "139",
        "ok": "139",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "528",
        "ok": "528",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5692",
        "ok": "5692",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1096",
        "ok": "1096",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "793",
        "ok": "793",
        "ko": "-"
    },
    "percentiles1": {
        "total": "873",
        "ok": "873",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1290",
        "ok": "1290",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2480",
        "ok": "2480",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4589",
        "ok": "4589",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 68,
        "percentage": 49
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 28,
        "percentage": 20
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 43,
        "percentage": 31
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.914",
        "ko": "-"
    }
}
    },"req_costs-png-bb737": {
        type: "REQUEST",
        name: "costs.png",
path: "costs.png",
pathFormatted: "req_costs-png-bb737",
stats: {
    "name": "costs.png",
    "numberOfRequests": {
        "total": "139",
        "ok": "2",
        "ko": "137"
    },
    "minResponseTime": {
        "total": "9179",
        "ok": "9179",
        "ko": "10000"
    },
    "maxResponseTime": {
        "total": "17765",
        "ok": "9574",
        "ko": "17765"
    },
    "meanResponseTime": {
        "total": "11086",
        "ok": "9377",
        "ko": "11111"
    },
    "standardDeviation": {
        "total": "1704",
        "ok": "198",
        "ko": "1704"
    },
    "percentiles1": {
        "total": "10191",
        "ok": "9377",
        "ko": "10193"
    },
    "percentiles2": {
        "total": "13210",
        "ok": "9475",
        "ko": "13212"
    },
    "percentiles3": {
        "total": "13468",
        "ok": "9554",
        "ko": "13480"
    },
    "percentiles4": {
        "total": "17673",
        "ok": "9570",
        "ko": "17673"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 137,
        "percentage": 99
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.013",
        "ko": "0.901"
    }
}
    },"req_feature-product-012e3": {
        type: "REQUEST",
        name: "feature-product-content.png",
path: "feature-product-content.png",
pathFormatted: "req_feature-product-012e3",
stats: {
    "name": "feature-product-content.png",
    "numberOfRequests": {
        "total": "139",
        "ok": "1",
        "ko": "138"
    },
    "minResponseTime": {
        "total": "10000",
        "ok": "11746",
        "ko": "10000"
    },
    "maxResponseTime": {
        "total": "17727",
        "ok": "11746",
        "ko": "17727"
    },
    "meanResponseTime": {
        "total": "11170",
        "ok": "11746",
        "ko": "11165"
    },
    "standardDeviation": {
        "total": "1768",
        "ok": "0",
        "ko": "1774"
    },
    "percentiles1": {
        "total": "10206",
        "ok": "11746",
        "ko": "10203"
    },
    "percentiles2": {
        "total": "13211",
        "ok": "11746",
        "ko": "13213"
    },
    "percentiles3": {
        "total": "13559",
        "ok": "11746",
        "ko": "13559"
    },
    "percentiles4": {
        "total": "17675",
        "ok": "11746",
        "ko": "17676"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 138,
        "percentage": 99
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.007",
        "ko": "0.908"
    }
}
    },"req_jsapi-290f1": {
        type: "REQUEST",
        name: "jsapi",
path: "jsapi",
pathFormatted: "req_jsapi-290f1",
stats: {
    "name": "jsapi",
    "numberOfRequests": {
        "total": "139",
        "ok": "139",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3461",
        "ok": "3461",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "548",
        "ok": "548",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "368",
        "ok": "368",
        "ko": "-"
    },
    "percentiles1": {
        "total": "424",
        "ok": "424",
        "ko": "-"
    },
    "percentiles2": {
        "total": "563",
        "ok": "563",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1200",
        "ok": "1200",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1993",
        "ok": "1993",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 129,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 3,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 7,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.914",
        "ko": "-"
    }
}
    },"req_logo-png-v-1492-5ab22": {
        type: "REQUEST",
        name: "logo.png?v=1492205475",
path: "logo.png?v=1492205475",
pathFormatted: "req_logo-png-v-1492-5ab22",
stats: {
    "name": "logo.png?v=1492205475",
    "numberOfRequests": {
        "total": "139",
        "ok": "139",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "311",
        "ok": "311",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3407",
        "ok": "3407",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "548",
        "ok": "548",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "409",
        "ok": "409",
        "ko": "-"
    },
    "percentiles1": {
        "total": "360",
        "ok": "360",
        "ko": "-"
    },
    "percentiles2": {
        "total": "628",
        "ok": "628",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1364",
        "ok": "1364",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1977",
        "ok": "1977",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 121,
        "percentage": 87
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 8,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 10,
        "percentage": 7
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.914",
        "ko": "-"
    }
}
    },"req_jquery-fancybox-51caf": {
        type: "REQUEST",
        name: "jquery.fancybox.css?v=1402447802",
path: "jquery.fancybox.css?v=1402447802",
pathFormatted: "req_jquery-fancybox-51caf",
stats: {
    "name": "jquery.fancybox.css?v=1402447802",
    "numberOfRequests": {
        "total": "139",
        "ok": "139",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "308",
        "ok": "308",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3404",
        "ok": "3404",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "555",
        "ok": "555",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "percentiles1": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "percentiles2": {
        "total": "683",
        "ok": "683",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1277",
        "ok": "1277",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2106",
        "ok": "2106",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 116,
        "percentage": 83
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 14,
        "percentage": 10
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 9,
        "percentage": 6
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.914",
        "ko": "-"
    }
}
    },"req_load-js-v-15263-5575c": {
        type: "REQUEST",
        name: "load.js?v=1526314653",
path: "load.js?v=1526314653",
pathFormatted: "req_load-js-v-15263-5575c",
stats: {
    "name": "load.js?v=1526314653",
    "numberOfRequests": {
        "total": "139",
        "ok": "139",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "311",
        "ok": "311",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3404",
        "ok": "3404",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "525",
        "ok": "525",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "percentiles1": {
        "total": "352",
        "ok": "352",
        "ko": "-"
    },
    "percentiles2": {
        "total": "647",
        "ok": "647",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1228",
        "ok": "1228",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1816",
        "ok": "1816",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 126,
        "percentage": 91
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 5,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 8,
        "percentage": 6
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.914",
        "ko": "-"
    }
}
    },"req_image2a-png-797fd": {
        type: "REQUEST",
        name: "image2a.png",
path: "image2a.png",
pathFormatted: "req_image2a-png-797fd",
stats: {
    "name": "image2a.png",
    "numberOfRequests": {
        "total": "139",
        "ok": "139",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "536",
        "ok": "536",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4967",
        "ok": "4967",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1184",
        "ok": "1184",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "708",
        "ok": "708",
        "ko": "-"
    },
    "percentiles1": {
        "total": "939",
        "ok": "939",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1337",
        "ok": "1337",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2435",
        "ok": "2435",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3766",
        "ok": "3766",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 48,
        "percentage": 35
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 43,
        "percentage": 31
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 48,
        "percentage": 35
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.914",
        "ko": "-"
    }
}
    },"req_legion-logo-svg-42202": {
        type: "REQUEST",
        name: "legion-logo.svg",
path: "legion-logo.svg",
pathFormatted: "req_legion-logo-svg-42202",
stats: {
    "name": "legion-logo.svg",
    "numberOfRequests": {
        "total": "139",
        "ok": "138",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "13797"
    },
    "maxResponseTime": {
        "total": "13797",
        "ok": "1201",
        "ko": "13797"
    },
    "meanResponseTime": {
        "total": "340",
        "ok": "242",
        "ko": "13797"
    },
    "standardDeviation": {
        "total": "1155",
        "ok": "150",
        "ko": "0"
    },
    "percentiles1": {
        "total": "188",
        "ok": "188",
        "ko": "13797"
    },
    "percentiles2": {
        "total": "224",
        "ok": "223",
        "ko": "13797"
    },
    "percentiles3": {
        "total": "645",
        "ok": "639",
        "ko": "13797"
    },
    "percentiles4": {
        "total": "1047",
        "ok": "794",
        "ko": "13797"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 137,
        "percentage": 99
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 1,
        "percentage": 1
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.908",
        "ko": "0.007"
    }
}
    },"req_feature-report--66856": {
        type: "REQUEST",
        name: "feature-report.png",
path: "feature-report.png",
pathFormatted: "req_feature-report--66856",
stats: {
    "name": "feature-report.png",
    "numberOfRequests": {
        "total": "139",
        "ok": "138",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "183",
        "ok": "183",
        "ko": "13793"
    },
    "maxResponseTime": {
        "total": "13793",
        "ok": "3875",
        "ko": "13793"
    },
    "meanResponseTime": {
        "total": "842",
        "ok": "748",
        "ko": "13793"
    },
    "standardDeviation": {
        "total": "1216",
        "ok": "516",
        "ko": "0"
    },
    "percentiles1": {
        "total": "569",
        "ok": "569",
        "ko": "13793"
    },
    "percentiles2": {
        "total": "888",
        "ok": "859",
        "ko": "13793"
    },
    "percentiles3": {
        "total": "1831",
        "ok": "1783",
        "ko": "13793"
    },
    "percentiles4": {
        "total": "3454",
        "ok": "2665",
        "ko": "13793"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 97,
        "percentage": 70
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 27,
        "percentage": 19
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 14,
        "percentage": 10
    },
    "group4": {
        "name": "failed",
        "count": 1,
        "percentage": 1
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.914",
        "ok": "0.908",
        "ko": "0.007"
    }
}
    },"req_modernizr-js-afb1f": {
        type: "REQUEST",
        name: "modernizr.js",
path: "modernizr.js",
pathFormatted: "req_modernizr-js-afb1f",
stats: {
    "name": "modernizr.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "240",
        "ko": "14760"
    },
    "minResponseTime": {
        "total": "176",
        "ok": "176",
        "ko": "9276"
    },
    "maxResponseTime": {
        "total": "19618",
        "ok": "19618",
        "ko": "18187"
    },
    "meanResponseTime": {
        "total": "10605",
        "ok": "4599",
        "ko": "10703"
    },
    "standardDeviation": {
        "total": "1448",
        "ok": "5174",
        "ko": "1048"
    },
    "percentiles1": {
        "total": "10396",
        "ok": "674",
        "ko": "10402"
    },
    "percentiles2": {
        "total": "10734",
        "ok": "9048",
        "ko": "10741"
    },
    "percentiles3": {
        "total": "13405",
        "ok": "13719",
        "ko": "13404"
    },
    "percentiles4": {
        "total": "13734",
        "ok": "16198",
        "ko": "13721"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 125,
        "percentage": 1
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 8,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 107,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 14760,
        "percentage": 98
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "1.579",
        "ko": "97.105"
    }
}
    },"req_jquery-1-11-1-m-d1c18": {
        type: "REQUEST",
        name: "jquery-1.11.1.min.js",
path: "jquery-1.11.1.min.js",
pathFormatted: "req_jquery-1-11-1-m-d1c18",
stats: {
    "name": "jquery-1.11.1.min.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "385",
        "ko": "14615"
    },
    "minResponseTime": {
        "total": "540",
        "ok": "540",
        "ko": "9931"
    },
    "maxResponseTime": {
        "total": "20188",
        "ok": "20188",
        "ko": "17993"
    },
    "meanResponseTime": {
        "total": "10326",
        "ok": "5054",
        "ko": "10465"
    },
    "standardDeviation": {
        "total": "1376",
        "ok": "4655",
        "ko": "789"
    },
    "percentiles1": {
        "total": "10214",
        "ok": "1974",
        "ko": "10221"
    },
    "percentiles2": {
        "total": "10495",
        "ok": "9586",
        "ko": "10497"
    },
    "percentiles3": {
        "total": "11864",
        "ok": "12739",
        "ko": "11762"
    },
    "percentiles4": {
        "total": "13715",
        "ok": "16297",
        "ko": "13698"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 23,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 64,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 298,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 14615,
        "percentage": 97
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "2.533",
        "ko": "96.151"
    }
}
    },"req_polyfiller-js-da34f": {
        type: "REQUEST",
        name: "polyfiller.js",
path: "polyfiller.js",
pathFormatted: "req_polyfiller-js-da34f",
stats: {
    "name": "polyfiller.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "631",
        "ko": "14369"
    },
    "minResponseTime": {
        "total": "176",
        "ok": "176",
        "ko": "9728"
    },
    "maxResponseTime": {
        "total": "22390",
        "ok": "22390",
        "ko": "17572"
    },
    "meanResponseTime": {
        "total": "10195",
        "ok": "3615",
        "ko": "10484"
    },
    "standardDeviation": {
        "total": "1827",
        "ok": "4195",
        "ko": "852"
    },
    "percentiles1": {
        "total": "10180",
        "ok": "568",
        "ko": "10190"
    },
    "percentiles2": {
        "total": "10440",
        "ok": "7513",
        "ko": "10454"
    },
    "percentiles3": {
        "total": "13234",
        "ok": "10860",
        "ko": "13236"
    },
    "percentiles4": {
        "total": "13411",
        "ok": "13223",
        "ko": "13412"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 338,
        "percentage": 2
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 26,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 267,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 14369,
        "percentage": 96
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "4.151",
        "ko": "94.533"
    }
}
    },"req_common-js-d7716": {
        type: "REQUEST",
        name: "common.js",
path: "common.js",
pathFormatted: "req_common-js-d7716",
stats: {
    "name": "common.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "883",
        "ko": "14117"
    },
    "minResponseTime": {
        "total": "176",
        "ok": "176",
        "ko": "7823"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "18376",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "10007",
        "ok": "2202",
        "ko": "10495"
    },
    "standardDeviation": {
        "total": "2355",
        "ok": "3150",
        "ko": "1107"
    },
    "percentiles1": {
        "total": "10102",
        "ok": "245",
        "ko": "10137"
    },
    "percentiles2": {
        "total": "10338",
        "ok": "4757",
        "ko": "10380"
    },
    "percentiles3": {
        "total": "13240",
        "ok": "8502",
        "ko": "13251"
    },
    "percentiles4": {
        "total": "13787",
        "ok": "11865",
        "ko": "13809"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 586,
        "percentage": 4
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 17,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 280,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 14117,
        "percentage": 94
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "5.809",
        "ko": "92.875"
    }
}
    },"req_home-js-2642c": {
        type: "REQUEST",
        name: "home.js",
path: "home.js",
pathFormatted: "req_home-js-2642c",
stats: {
    "name": "home.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "1250",
        "ko": "13750"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "9761"
    },
    "maxResponseTime": {
        "total": "18528",
        "ok": "18528",
        "ko": "17522"
    },
    "meanResponseTime": {
        "total": "9515",
        "ok": "1920",
        "ko": "10206"
    },
    "standardDeviation": {
        "total": "2498",
        "ok": "2771",
        "ko": "623"
    },
    "percentiles1": {
        "total": "10021",
        "ok": "215",
        "ko": "10029"
    },
    "percentiles2": {
        "total": "10157",
        "ok": "4059",
        "ko": "10180"
    },
    "percentiles3": {
        "total": "11204",
        "ok": "7532",
        "ko": "11214"
    },
    "percentiles4": {
        "total": "13277",
        "ok": "9835",
        "ko": "13281"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 851,
        "percentage": 6
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 12,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 387,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 13750,
        "percentage": 92
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "8.224",
        "ko": "90.461"
    }
}
    },"req_form-core-js-5c174": {
        type: "REQUEST",
        name: "form-core.js",
path: "form-core.js",
pathFormatted: "req_form-core-js-5c174",
stats: {
    "name": "form-core.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "1700",
        "ko": "13300"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "9518"
    },
    "maxResponseTime": {
        "total": "26975",
        "ok": "26975",
        "ko": "17526"
    },
    "meanResponseTime": {
        "total": "9265",
        "ok": "1611",
        "ko": "10244"
    },
    "standardDeviation": {
        "total": "2951",
        "ok": "2478",
        "ko": "770"
    },
    "percentiles1": {
        "total": "10011",
        "ok": "203",
        "ko": "10017"
    },
    "percentiles2": {
        "total": "10095",
        "ok": "3422",
        "ko": "10175"
    },
    "percentiles3": {
        "total": "11217",
        "ok": "6685",
        "ko": "11238"
    },
    "percentiles4": {
        "total": "13290",
        "ok": "9152",
        "ko": "13298"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1210,
        "percentage": 8
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 14,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 476,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 13300,
        "percentage": 89
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "11.184",
        "ko": "87.5"
    }
}
    },"req_form-validation-20c6c": {
        type: "REQUEST",
        name: "form-validation.js",
path: "form-validation.js",
pathFormatted: "req_form-validation-20c6c",
stats: {
    "name": "form-validation.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "2191",
        "ko": "12809"
    },
    "minResponseTime": {
        "total": "177",
        "ok": "177",
        "ko": "9626"
    },
    "maxResponseTime": {
        "total": "20928",
        "ok": "20928",
        "ko": "17454"
    },
    "meanResponseTime": {
        "total": "8929",
        "ok": "1524",
        "ko": "10195"
    },
    "standardDeviation": {
        "total": "3230",
        "ok": "2165",
        "ko": "658"
    },
    "percentiles1": {
        "total": "10005",
        "ok": "389",
        "ko": "10010"
    },
    "percentiles2": {
        "total": "10072",
        "ok": "1350",
        "ko": "10114"
    },
    "percentiles3": {
        "total": "11198",
        "ok": "5962",
        "ko": "11209"
    },
    "percentiles4": {
        "total": "13247",
        "ok": "8829",
        "ko": "13253"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1536,
        "percentage": 10
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 91,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 564,
        "percentage": 4
    },
    "group4": {
        "name": "failed",
        "count": 12809,
        "percentage": 85
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "14.414",
        "ko": "84.27"
    }
}
    },"req_co-tel-png-0c966": {
        type: "REQUEST",
        name: "co-tel.png",
path: "co-tel.png",
pathFormatted: "req_co-tel-png-0c966",
stats: {
    "name": "co-tel.png",
    "numberOfRequests": {
        "total": "15000",
        "ok": "2773",
        "ko": "12227"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "9531"
    },
    "maxResponseTime": {
        "total": "17558",
        "ok": "12629",
        "ko": "17558"
    },
    "meanResponseTime": {
        "total": "8531",
        "ok": "1057",
        "ko": "10226"
    },
    "standardDeviation": {
        "total": "3712",
        "ok": "1822",
        "ko": "782"
    },
    "percentiles1": {
        "total": "10003",
        "ok": "193",
        "ko": "10006"
    },
    "percentiles2": {
        "total": "10040",
        "ok": "387",
        "ko": "10089"
    },
    "percentiles3": {
        "total": "11203",
        "ok": "5054",
        "ko": "11225"
    },
    "percentiles4": {
        "total": "13258",
        "ok": "7897",
        "ko": "13270"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2175,
        "percentage": 14
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 11,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 587,
        "percentage": 4
    },
    "group4": {
        "name": "failed",
        "count": 12227,
        "percentage": 82
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "18.243",
        "ko": "80.441"
    }
}
    },"req_co-email-png-a2bb3": {
        type: "REQUEST",
        name: "co-email.png",
path: "co-email.png",
pathFormatted: "req_co-email-png-a2bb3",
stats: {
    "name": "co-email.png",
    "numberOfRequests": {
        "total": "15000",
        "ok": "3477",
        "ko": "11523"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "9527"
    },
    "maxResponseTime": {
        "total": "17488",
        "ok": "15529",
        "ko": "17488"
    },
    "meanResponseTime": {
        "total": "8094",
        "ok": "965",
        "ko": "10244"
    },
    "standardDeviation": {
        "total": "4065",
        "ok": "1686",
        "ko": "836"
    },
    "percentiles1": {
        "total": "10001",
        "ok": "190",
        "ko": "10003"
    },
    "percentiles2": {
        "total": "10032",
        "ok": "284",
        "ko": "10180"
    },
    "percentiles3": {
        "total": "11193",
        "ok": "4738",
        "ko": "11211"
    },
    "percentiles4": {
        "total": "13238",
        "ok": "7247",
        "ko": "13254"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2751,
        "percentage": 18
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 16,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 710,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 11523,
        "percentage": 77
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "22.875",
        "ko": "75.809"
    }
}
    },"req_icon-menu-svg-07ea6": {
        type: "REQUEST",
        name: "icon-menu.svg",
path: "icon-menu.svg",
pathFormatted: "req_icon-menu-svg-07ea6",
stats: {
    "name": "icon-menu.svg",
    "numberOfRequests": {
        "total": "15000",
        "ok": "4275",
        "ko": "10725"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "9462"
    },
    "maxResponseTime": {
        "total": "17500",
        "ok": "16511",
        "ko": "17500"
    },
    "meanResponseTime": {
        "total": "7596",
        "ok": "930",
        "ko": "10253"
    },
    "standardDeviation": {
        "total": "4371",
        "ok": "1750",
        "ko": "859"
    },
    "percentiles1": {
        "total": "10000",
        "ok": "189",
        "ko": "10001"
    },
    "percentiles2": {
        "total": "10007",
        "ok": "236",
        "ko": "10178"
    },
    "percentiles3": {
        "total": "11195",
        "ok": "4712",
        "ko": "11212"
    },
    "percentiles4": {
        "total": "13232",
        "ok": "7894",
        "ko": "13238"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 3461,
        "percentage": 23
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 7,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 807,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 10725,
        "percentage": 72
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "28.125",
        "ko": "70.559"
    }
}
    },"req_shim-css-5c41a": {
        type: "REQUEST",
        name: "shim.css",
path: "shim.css",
pathFormatted: "req_shim-css-5c41a",
stats: {
    "name": "shim.css",
    "numberOfRequests": {
        "total": "15000",
        "ok": "6015",
        "ko": "8985"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "4854"
    },
    "maxResponseTime": {
        "total": "23989",
        "ok": "23989",
        "ko": "17491"
    },
    "meanResponseTime": {
        "total": "6857",
        "ok": "1757",
        "ko": "10271"
    },
    "standardDeviation": {
        "total": "4602",
        "ok": "2846",
        "ko": "932"
    },
    "percentiles1": {
        "total": "10000",
        "ok": "197",
        "ko": "10001"
    },
    "percentiles2": {
        "total": "10001",
        "ok": "2407",
        "ko": "10180"
    },
    "percentiles3": {
        "total": "11200",
        "ok": "9042",
        "ko": "12656"
    },
    "percentiles4": {
        "total": "13223",
        "ok": "11431",
        "ko": "13230"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4066,
        "percentage": 27
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 56,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1893,
        "percentage": 13
    },
    "group4": {
        "name": "failed",
        "count": 8985,
        "percentage": 60
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "98.684",
        "ok": "39.572",
        "ko": "59.112"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
