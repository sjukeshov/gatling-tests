var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "25",
        "ok": "25",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "571",
        "ok": "571",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "percentiles1": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "percentiles2": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1099",
        "ok": "1099",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1894",
        "ok": "1894",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 18,
        "percentage": 72
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6,
        "percentage": 24
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 4
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3.571",
        "ok": "3.571",
        "ko": "-"
    }
},
contents: {
"req_main-page-95658": {
        type: "REQUEST",
        name: "Main Page",
path: "Main Page",
pathFormatted: "req_main-page-95658",
stats: {
    "name": "Main Page",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1151",
        "ok": "1151",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_style-css-da232": {
        type: "REQUEST",
        name: "style.css",
path: "style.css",
pathFormatted: "req_style-css-da232",
stats: {
    "name": "style.css",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "percentiles2": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "percentiles3": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "percentiles4": {
        "total": "553",
        "ok": "553",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_fast-png-e3425": {
        type: "REQUEST",
        name: "fast.png",
path: "fast.png",
pathFormatted: "req_fast-png-e3425",
stats: {
    "name": "fast.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "percentiles2": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "percentiles3": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "percentiles4": {
        "total": "847",
        "ok": "847",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_engineer-png-1bce4": {
        type: "REQUEST",
        name: "engineer.png",
path: "engineer.png",
pathFormatted: "req_engineer-png-1bce4",
stats: {
    "name": "engineer.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "percentiles2": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "percentiles3": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "percentiles4": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_costs-png-bb737": {
        type: "REQUEST",
        name: "costs.png",
path: "costs.png",
pathFormatted: "req_costs-png-bb737",
stats: {
    "name": "costs.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "percentiles2": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "percentiles3": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "percentiles4": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_methodology-png-b165b": {
        type: "REQUEST",
        name: "methodology.png",
path: "methodology.png",
pathFormatted: "req_methodology-png-b165b",
stats: {
    "name": "methodology.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "percentiles2": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "percentiles3": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "percentiles4": {
        "total": "830",
        "ok": "830",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_feature-product-012e3": {
        type: "REQUEST",
        name: "feature-product-content.png",
path: "feature-product-content.png",
pathFormatted: "req_feature-product-012e3",
stats: {
    "name": "feature-product-content.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_jsapi-290f1": {
        type: "REQUEST",
        name: "jsapi",
path: "jsapi",
pathFormatted: "req_jsapi-290f1",
stats: {
    "name": "jsapi",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles2": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles3": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles4": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_logo-png-v-1492-5ab22": {
        type: "REQUEST",
        name: "logo.png?v=1492205475",
path: "logo.png?v=1492205475",
pathFormatted: "req_logo-png-v-1492-5ab22",
stats: {
    "name": "logo.png?v=1492205475",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "892",
        "ok": "892",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "892",
        "ok": "892",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "892",
        "ok": "892",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "892",
        "ok": "892",
        "ko": "-"
    },
    "percentiles2": {
        "total": "892",
        "ok": "892",
        "ko": "-"
    },
    "percentiles3": {
        "total": "892",
        "ok": "892",
        "ko": "-"
    },
    "percentiles4": {
        "total": "892",
        "ok": "892",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_jquery-fancybox-51caf": {
        type: "REQUEST",
        name: "jquery.fancybox.css?v=1402447802",
path: "jquery.fancybox.css?v=1402447802",
pathFormatted: "req_jquery-fancybox-51caf",
stats: {
    "name": "jquery.fancybox.css?v=1402447802",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "percentiles2": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "percentiles3": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "percentiles4": {
        "total": "763",
        "ok": "763",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_load-js-v-15263-5575c": {
        type: "REQUEST",
        name: "load.js?v=1526314653",
path: "load.js?v=1526314653",
pathFormatted: "req_load-js-v-15263-5575c",
stats: {
    "name": "load.js?v=1526314653",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "percentiles2": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "percentiles3": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "percentiles4": {
        "total": "770",
        "ok": "770",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_image2a-png-797fd": {
        type: "REQUEST",
        name: "image2a.png",
path: "image2a.png",
pathFormatted: "req_image2a-png-797fd",
stats: {
    "name": "image2a.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "percentiles2": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "percentiles3": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "percentiles4": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_legion-logo-svg-42202": {
        type: "REQUEST",
        name: "legion-logo.svg",
path: "legion-logo.svg",
pathFormatted: "req_legion-logo-svg-42202",
stats: {
    "name": "legion-logo.svg",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "percentiles2": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "percentiles3": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "percentiles4": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_feature-report--66856": {
        type: "REQUEST",
        name: "feature-report.png",
path: "feature-report.png",
pathFormatted: "req_feature-report--66856",
stats: {
    "name": "feature-report.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "percentiles2": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "percentiles3": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "percentiles4": {
        "total": "533",
        "ok": "533",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_modernizr-js-afb1f": {
        type: "REQUEST",
        name: "modernizr.js",
path: "modernizr.js",
pathFormatted: "req_modernizr-js-afb1f",
stats: {
    "name": "modernizr.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles2": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles3": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles4": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_jquery-1-11-1-m-d1c18": {
        type: "REQUEST",
        name: "jquery-1.11.1.min.js",
path: "jquery-1.11.1.min.js",
pathFormatted: "req_jquery-1-11-1-m-d1c18",
stats: {
    "name": "jquery-1.11.1.min.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "percentiles2": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "percentiles3": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "percentiles4": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_polyfiller-js-da34f": {
        type: "REQUEST",
        name: "polyfiller.js",
path: "polyfiller.js",
pathFormatted: "req_polyfiller-js-da34f",
stats: {
    "name": "polyfiller.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles2": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles3": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles4": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_common-js-d7716": {
        type: "REQUEST",
        name: "common.js",
path: "common.js",
pathFormatted: "req_common-js-d7716",
stats: {
    "name": "common.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "percentiles2": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "percentiles3": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "percentiles4": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_home-js-2642c": {
        type: "REQUEST",
        name: "home.js",
path: "home.js",
pathFormatted: "req_home-js-2642c",
stats: {
    "name": "home.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "percentiles2": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "percentiles3": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "percentiles4": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_form-core-js-5c174": {
        type: "REQUEST",
        name: "form-core.js",
path: "form-core.js",
pathFormatted: "req_form-core-js-5c174",
stats: {
    "name": "form-core.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "percentiles2": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "percentiles3": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "percentiles4": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_form-validation-20c6c": {
        type: "REQUEST",
        name: "form-validation.js",
path: "form-validation.js",
pathFormatted: "req_form-validation-20c6c",
stats: {
    "name": "form-validation.js",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "percentiles2": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "percentiles3": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "percentiles4": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_co-tel-png-0c966": {
        type: "REQUEST",
        name: "co-tel.png",
path: "co-tel.png",
pathFormatted: "req_co-tel-png-0c966",
stats: {
    "name": "co-tel.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles2": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles3": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles4": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_co-email-png-a2bb3": {
        type: "REQUEST",
        name: "co-email.png",
path: "co-email.png",
pathFormatted: "req_co-email-png-a2bb3",
stats: {
    "name": "co-email.png",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "percentiles2": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "percentiles3": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "percentiles4": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_icon-menu-svg-07ea6": {
        type: "REQUEST",
        name: "icon-menu.svg",
path: "icon-menu.svg",
pathFormatted: "req_icon-menu-svg-07ea6",
stats: {
    "name": "icon-menu.svg",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "percentiles2": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "percentiles3": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "percentiles4": {
        "total": "185",
        "ok": "185",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    },"req_shim-css-5c41a": {
        type: "REQUEST",
        name: "shim.css",
path: "shim.css",
pathFormatted: "req_shim-css-5c41a",
stats: {
    "name": "shim.css",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "percentiles2": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "percentiles3": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "percentiles4": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.143",
        "ok": "0.143",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
