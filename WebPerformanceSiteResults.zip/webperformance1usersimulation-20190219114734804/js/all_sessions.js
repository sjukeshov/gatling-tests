allUsersData = {
    
color: '#FF9D00',
name: 'Active Users',
data: [
  [1550576856000,1],[1550576857000,1],[1550576858000,1],[1550576859000,1],[1550576860000,1],[1550576861000,1],[1550576862000,1]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};