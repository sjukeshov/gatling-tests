allUsersData = {
    
color: '#FF9D00',
name: 'Active Users',
data: [
  [1550574352000,1],[1550574353000,1],[1550574354000,1],[1550574355000,1],[1550574356000,1],[1550574357000,1],[1550574358000,1]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};