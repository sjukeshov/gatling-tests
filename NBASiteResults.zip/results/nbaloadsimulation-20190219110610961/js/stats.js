var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "281800",
        "ok": "174766",
        "ko": "107034"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "77",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "71904",
        "ok": "71904",
        "ko": "64572"
    },
    "meanResponseTime": {
        "total": "8405",
        "ok": "3216",
        "ko": "16878"
    },
    "standardDeviation": {
        "total": "13547",
        "ok": "7351",
        "ko": "16709"
    },
    "percentiles1": {
        "total": "1743",
        "ok": "680",
        "ko": "10469"
    },
    "percentiles2": {
        "total": "10377",
        "ok": "2241",
        "ko": "14158"
    },
    "percentiles3": {
        "total": "42849",
        "ok": "17716",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "60000",
        "ok": "39628",
        "ko": "60069"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 98495,
        "percentage": 35
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 14211,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 62060,
        "percentage": 22
    },
    "group4": {
        "name": "failed",
        "count": 107034,
        "percentage": 38
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "995.76",
        "ok": "617.548",
        "ko": "378.212"
    }
},
contents: {
"req_main-page-95658": {
        type: "REQUEST",
        name: "Main Page",
path: "Main Page",
pathFormatted: "req_main-page-95658",
stats: {
    "name": "Main Page",
    "numberOfRequests": {
        "total": "15000",
        "ok": "10610",
        "ko": "4390"
    },
    "minResponseTime": {
        "total": "706",
        "ok": "706",
        "ko": "1675"
    },
    "maxResponseTime": {
        "total": "62631",
        "ok": "58686",
        "ko": "62631"
    },
    "meanResponseTime": {
        "total": "15725",
        "ok": "5180",
        "ko": "41212"
    },
    "standardDeviation": {
        "total": "18228",
        "ok": "8214",
        "ko": "7340"
    },
    "percentiles1": {
        "total": "3877",
        "ok": "2151",
        "ko": "43612"
    },
    "percentiles2": {
        "total": "40011",
        "ok": "4478",
        "ko": "44721"
    },
    "percentiles3": {
        "total": "45167",
        "ok": "28890",
        "ko": "45823"
    },
    "percentiles4": {
        "total": "45933",
        "ok": "38072",
        "ko": "46325"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 352,
        "percentage": 2
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 2683,
        "percentage": 18
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 7575,
        "percentage": 51
    },
    "group4": {
        "name": "failed",
        "count": 4390,
        "percentage": 29
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "37.491",
        "ko": "15.512"
    }
}
    },"req_main-page-redir-96f39": {
        type: "REQUEST",
        name: "Main Page Redirect 1",
path: "Main Page Redirect 1",
pathFormatted: "req_main-page-redir-96f39",
stats: {
    "name": "Main Page Redirect 1",
    "numberOfRequests": {
        "total": "10610",
        "ok": "253",
        "ko": "10357"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2533",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "64457",
        "ok": "52391",
        "ko": "64457"
    },
    "meanResponseTime": {
        "total": "11896",
        "ok": "15924",
        "ko": "11798"
    },
    "standardDeviation": {
        "total": "6045",
        "ok": "9900",
        "ko": "5885"
    },
    "percentiles1": {
        "total": "10111",
        "ok": "13801",
        "ko": "10111"
    },
    "percentiles2": {
        "total": "12082",
        "ok": "21838",
        "ko": "11807"
    },
    "percentiles3": {
        "total": "15867",
        "ok": "34926",
        "ko": "15549"
    },
    "percentiles4": {
        "total": "60000",
        "ok": "50019",
        "ko": "60000"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 253,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 10357,
        "percentage": 98
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "37.491",
        "ok": "0.894",
        "ko": "36.597"
    }
}
    },"req_nba-cvp-3cdef": {
        type: "REQUEST",
        name: "nba cvp",
path: "nba cvp",
pathFormatted: "req_nba-cvp-3cdef",
stats: {
    "name": "nba cvp",
    "numberOfRequests": {
        "total": "15000",
        "ok": "10945",
        "ko": "4055"
    },
    "minResponseTime": {
        "total": "176",
        "ok": "176",
        "ko": "10177"
    },
    "maxResponseTime": {
        "total": "71904",
        "ok": "71904",
        "ko": "60025"
    },
    "meanResponseTime": {
        "total": "12801",
        "ok": "1970",
        "ko": "42035"
    },
    "standardDeviation": {
        "total": "18568",
        "ok": "5689",
        "ko": "4084"
    },
    "percentiles1": {
        "total": "752",
        "ok": "225",
        "ko": "42509"
    },
    "percentiles2": {
        "total": "41088",
        "ok": "882",
        "ko": "42767"
    },
    "percentiles3": {
        "total": "42828",
        "ok": "11682",
        "ko": "45508"
    },
    "percentiles4": {
        "total": "45952",
        "ok": "33099",
        "ko": "49160"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 7943,
        "percentage": 53
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 608,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2394,
        "percentage": 16
    },
    "group4": {
        "name": "failed",
        "count": 4055,
        "percentage": 27
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "38.675",
        "ko": "14.329"
    }
}
    },"req_nba-cvp-redirec-a496b": {
        type: "REQUEST",
        name: "nba cvp Redirect 1",
path: "nba cvp Redirect 1",
pathFormatted: "req_nba-cvp-redirec-a496b",
stats: {
    "name": "nba cvp Redirect 1",
    "numberOfRequests": {
        "total": "10945",
        "ok": "2246",
        "ko": "8699"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "77",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60197",
        "ok": "47262",
        "ko": "60197"
    },
    "meanResponseTime": {
        "total": "10271",
        "ok": "5577",
        "ko": "11483"
    },
    "standardDeviation": {
        "total": "4166",
        "ok": "5134",
        "ko": "2805"
    },
    "percentiles1": {
        "total": "10005",
        "ok": "4932",
        "ko": "10057"
    },
    "percentiles2": {
        "total": "12662",
        "ok": "8119",
        "ko": "13253"
    },
    "percentiles3": {
        "total": "15128",
        "ok": "15420",
        "ko": "15081"
    },
    "percentiles4": {
        "total": "19851",
        "ok": "21329",
        "ko": "19054"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 328,
        "percentage": 3
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 165,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1753,
        "percentage": 16
    },
    "group4": {
        "name": "failed",
        "count": 8699,
        "percentage": 79
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "38.675",
        "ok": "7.936",
        "ko": "30.739"
    }
}
    },"req_gallery-2767c": {
        type: "REQUEST",
        name: "gallery",
path: "gallery",
pathFormatted: "req_gallery-2767c",
stats: {
    "name": "gallery",
    "numberOfRequests": {
        "total": "15000",
        "ok": "12171",
        "ko": "2829"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "10176"
    },
    "maxResponseTime": {
        "total": "61877",
        "ok": "60418",
        "ko": "61877"
    },
    "meanResponseTime": {
        "total": "10601",
        "ok": "3555",
        "ko": "40912"
    },
    "standardDeviation": {
        "total": "16746",
        "ok": "8071",
        "ko": "8618"
    },
    "percentiles1": {
        "total": "946",
        "ok": "721",
        "ko": "44330"
    },
    "percentiles2": {
        "total": "18607",
        "ok": "1291",
        "ko": "45845"
    },
    "percentiles3": {
        "total": "45556",
        "ok": "22729",
        "ko": "47849"
    },
    "percentiles4": {
        "total": "47922",
        "ok": "40097",
        "ko": "60000"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 6887,
        "percentage": 46
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1681,
        "percentage": 11
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3603,
        "percentage": 24
    },
    "group4": {
        "name": "failed",
        "count": 2829,
        "percentage": 19
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "43.007",
        "ko": "9.996"
    }
}
    },"req_gallery-redirec-89513": {
        type: "REQUEST",
        name: "gallery Redirect 1",
path: "gallery Redirect 1",
pathFormatted: "req_gallery-redirec-89513",
stats: {
    "name": "gallery Redirect 1",
    "numberOfRequests": {
        "total": "12171",
        "ok": "3479",
        "ko": "8692"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "77",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "61473",
        "ok": "46898",
        "ko": "61473"
    },
    "meanResponseTime": {
        "total": "8736",
        "ok": "3465",
        "ko": "10846"
    },
    "standardDeviation": {
        "total": "5891",
        "ok": "5554",
        "ko": "4546"
    },
    "percentiles1": {
        "total": "10117",
        "ok": "659",
        "ko": "10313"
    },
    "percentiles2": {
        "total": "10716",
        "ok": "4942",
        "ko": "10932"
    },
    "percentiles3": {
        "total": "13531",
        "ok": "13819",
        "ko": "13497"
    },
    "percentiles4": {
        "total": "21214",
        "ok": "22047",
        "ko": "20089"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1872,
        "percentage": 15
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 223,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1384,
        "percentage": 11
    },
    "group4": {
        "name": "failed",
        "count": 8692,
        "percentage": 71
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "43.007",
        "ok": "12.293",
        "ko": "30.714"
    }
}
    },"req_contingency-9f387": {
        type: "REQUEST",
        name: "contingency",
path: "contingency",
pathFormatted: "req_contingency-9f387",
stats: {
    "name": "contingency",
    "numberOfRequests": {
        "total": "15000",
        "ok": "12922",
        "ko": "2078"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "10177"
    },
    "maxResponseTime": {
        "total": "61213",
        "ok": "60957",
        "ko": "61213"
    },
    "meanResponseTime": {
        "total": "7480",
        "ok": "2486",
        "ko": "38537"
    },
    "standardDeviation": {
        "total": "14263",
        "ok": "6363",
        "ko": "9847"
    },
    "percentiles1": {
        "total": "710",
        "ok": "664",
        "ko": "40107"
    },
    "percentiles2": {
        "total": "3538",
        "ok": "1212",
        "ko": "40284"
    },
    "percentiles3": {
        "total": "40215",
        "ok": "14737",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "47778",
        "ok": "33960",
        "ko": "60020"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 8383,
        "percentage": 56
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1245,
        "percentage": 8
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3294,
        "percentage": 22
    },
    "group4": {
        "name": "failed",
        "count": 2078,
        "percentage": 14
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "45.661",
        "ko": "7.343"
    }
}
    },"req_contingency-red-da23b": {
        type: "REQUEST",
        name: "contingency Redirect 1",
path: "contingency Redirect 1",
pathFormatted: "req_contingency-red-da23b",
stats: {
    "name": "contingency Redirect 1",
    "numberOfRequests": {
        "total": "12922",
        "ok": "4618",
        "ko": "8304"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "77",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "62208",
        "ok": "59992",
        "ko": "62208"
    },
    "meanResponseTime": {
        "total": "8261",
        "ok": "2708",
        "ko": "11350"
    },
    "standardDeviation": {
        "total": "8643",
        "ok": "5921",
        "ko": "8371"
    },
    "percentiles1": {
        "total": "10001",
        "ok": "629",
        "ko": "10290"
    },
    "percentiles2": {
        "total": "10599",
        "ok": "2334",
        "ko": "10827"
    },
    "percentiles3": {
        "total": "13278",
        "ok": "10752",
        "ko": "13943"
    },
    "percentiles4": {
        "total": "60000",
        "ok": "36844",
        "ko": "60001"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2533,
        "percentage": 20
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 386,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1699,
        "percentage": 13
    },
    "group4": {
        "name": "failed",
        "count": 8304,
        "percentage": 64
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "45.661",
        "ok": "16.318",
        "ko": "29.343"
    }
}
    },"req_load-sound-js-e437f": {
        type: "REQUEST",
        name: "load Sound.js",
path: "load Sound.js",
pathFormatted: "req_load-sound-js-e437f",
stats: {
    "name": "load Sound.js",
    "numberOfRequests": {
        "total": "15000",
        "ok": "14072",
        "ko": "928"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "10178"
    },
    "maxResponseTime": {
        "total": "62276",
        "ok": "61505",
        "ko": "62276"
    },
    "meanResponseTime": {
        "total": "4789",
        "ok": "2851",
        "ko": "34181"
    },
    "standardDeviation": {
        "total": "10879",
        "ok": "7204",
        "ko": "14326"
    },
    "percentiles1": {
        "total": "648",
        "ok": "620",
        "ko": "40004"
    },
    "percentiles2": {
        "total": "1966",
        "ok": "1207",
        "ko": "40398"
    },
    "percentiles3": {
        "total": "35116",
        "ok": "18211",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "45660",
        "ok": "38016",
        "ko": "60076"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 9624,
        "percentage": 64
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 909,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3539,
        "percentage": 24
    },
    "group4": {
        "name": "failed",
        "count": 928,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "49.724",
        "ko": "3.279"
    }
}
    },"req_load-sound-js-r-3b729": {
        type: "REQUEST",
        name: "load Sound.js Redirect 1",
path: "load Sound.js Redirect 1",
pathFormatted: "req_load-sound-js-r-3b729",
stats: {
    "name": "load Sound.js Redirect 1",
    "numberOfRequests": {
        "total": "14072",
        "ok": "5359",
        "ko": "8713"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "77",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "64549",
        "ok": "59709",
        "ko": "64549"
    },
    "meanResponseTime": {
        "total": "9245",
        "ok": "3248",
        "ko": "12933"
    },
    "standardDeviation": {
        "total": "12455",
        "ok": "6947",
        "ko": "13607"
    },
    "percentiles1": {
        "total": "10000",
        "ok": "810",
        "ko": "10189"
    },
    "percentiles2": {
        "total": "10543",
        "ok": "2840",
        "ko": "11389"
    },
    "percentiles3": {
        "total": "33823",
        "ok": "13622",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "60026",
        "ok": "40150",
        "ko": "60396"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2659,
        "percentage": 19
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 452,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2248,
        "percentage": 16
    },
    "group4": {
        "name": "failed",
        "count": 8713,
        "percentage": 62
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "49.724",
        "ok": "18.936",
        "ko": "30.788"
    }
}
    },"req_load-main-out6--2413f": {
        type: "REQUEST",
        name: "load main_out6.js",
path: "load main_out6.js",
pathFormatted: "req_load-main-out6--2413f",
stats: {
    "name": "load main_out6.js",
    "numberOfRequests": {
        "total": "30000",
        "ok": "28287",
        "ko": "1713"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "10176"
    },
    "maxResponseTime": {
        "total": "62170",
        "ok": "59919",
        "ko": "62170"
    },
    "meanResponseTime": {
        "total": "3915",
        "ok": "2244",
        "ko": "31499"
    },
    "standardDeviation": {
        "total": "9093",
        "ok": "5068",
        "ko": "14726"
    },
    "percentiles1": {
        "total": "670",
        "ok": "650",
        "ko": "40001"
    },
    "percentiles2": {
        "total": "2840",
        "ok": "2125",
        "ko": "42674"
    },
    "percentiles3": {
        "total": "23267",
        "ok": "9630",
        "ko": "52946"
    },
    "percentiles4": {
        "total": "44269",
        "ok": "29643",
        "ko": "60001"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 16829,
        "percentage": 56
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1753,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 9705,
        "percentage": 32
    },
    "group4": {
        "name": "failed",
        "count": 1713,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "106.007",
        "ok": "99.954",
        "ko": "6.053"
    }
}
    },"req_load-main-out6--7cc62": {
        type: "REQUEST",
        name: "load main_out6.js Redirect 1",
path: "load main_out6.js Redirect 1",
pathFormatted: "req_load-main-out6--7cc62",
stats: {
    "name": "load main_out6.js Redirect 1",
    "numberOfRequests": {
        "total": "28287",
        "ok": "10309",
        "ko": "17978"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "77",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "64572",
        "ok": "59944",
        "ko": "64572"
    },
    "meanResponseTime": {
        "total": "10195",
        "ok": "5022",
        "ko": "13161"
    },
    "standardDeviation": {
        "total": "15827",
        "ok": "9959",
        "ko": "17695"
    },
    "percentiles1": {
        "total": "7128",
        "ok": "988",
        "ko": "10301"
    },
    "percentiles2": {
        "total": "11100",
        "ok": "4692",
        "ko": "11558"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "27081",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60638",
        "ok": "50104",
        "ko": "61310"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4803,
        "percentage": 17
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 651,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4855,
        "percentage": 17
    },
    "group4": {
        "name": "failed",
        "count": 17978,
        "percentage": 64
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "99.954",
        "ok": "36.428",
        "ko": "63.527"
    }
}
    },"req_background-imag-69ee1": {
        type: "REQUEST",
        name: "Background image",
path: "Background image",
pathFormatted: "req_background-imag-69ee1",
stats: {
    "name": "Background image",
    "numberOfRequests": {
        "total": "15000",
        "ok": "14388",
        "ko": "612"
    },
    "minResponseTime": {
        "total": "174",
        "ok": "174",
        "ko": "4042"
    },
    "maxResponseTime": {
        "total": "60419",
        "ok": "60419",
        "ko": "60015"
    },
    "meanResponseTime": {
        "total": "2916",
        "ok": "1540",
        "ko": "35288"
    },
    "standardDeviation": {
        "total": "8441",
        "ok": "4505",
        "ko": "13301"
    },
    "percentiles1": {
        "total": "330",
        "ok": "290",
        "ko": "40024"
    },
    "percentiles2": {
        "total": "1176",
        "ok": "1033",
        "ko": "40291"
    },
    "percentiles3": {
        "total": "18776",
        "ok": "4443",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "40342",
        "ok": "26715",
        "ko": "60001"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 10443,
        "percentage": 70
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 845,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3100,
        "percentage": 21
    },
    "group4": {
        "name": "failed",
        "count": 612,
        "percentage": 4
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "50.841",
        "ko": "2.163"
    }
}
    },"req_background-imag-70085": {
        type: "REQUEST",
        name: "Background image Redirect 1",
path: "Background image Redirect 1",
pathFormatted: "req_background-imag-70085",
stats: {
    "name": "Background image Redirect 1",
    "numberOfRequests": {
        "total": "14388",
        "ok": "4358",
        "ko": "10030"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "181",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "64243",
        "ok": "59958",
        "ko": "64243"
    },
    "meanResponseTime": {
        "total": "19534",
        "ok": "16966",
        "ko": "20650"
    },
    "standardDeviation": {
        "total": "21169",
        "ok": "15283",
        "ko": "23178"
    },
    "percentiles1": {
        "total": "10910",
        "ok": "12627",
        "ko": "10819"
    },
    "percentiles2": {
        "total": "24480",
        "ok": "24771",
        "ko": "19126"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "49284",
        "ko": "60004"
    },
    "percentiles4": {
        "total": "61278",
        "ok": "57545",
        "ko": "61701"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 269,
        "percentage": 2
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 201,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3888,
        "percentage": 27
    },
    "group4": {
        "name": "failed",
        "count": 10030,
        "percentage": 70
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "50.841",
        "ok": "15.399",
        "ko": "35.442"
    }
}
    },"req_calendar-image-441dd": {
        type: "REQUEST",
        name: "calendar image",
path: "calendar image",
pathFormatted: "req_calendar-image-441dd",
stats: {
    "name": "calendar image",
    "numberOfRequests": {
        "total": "15000",
        "ok": "13908",
        "ko": "1092"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "10115"
    },
    "maxResponseTime": {
        "total": "60065",
        "ok": "59673",
        "ko": "60065"
    },
    "meanResponseTime": {
        "total": "4464",
        "ok": "2457",
        "ko": "30031"
    },
    "standardDeviation": {
        "total": "10028",
        "ok": "6018",
        "ko": "14671"
    },
    "percentiles1": {
        "total": "633",
        "ok": "606",
        "ko": "33328"
    },
    "percentiles2": {
        "total": "2514",
        "ok": "1715",
        "ko": "40687"
    },
    "percentiles3": {
        "total": "31468",
        "ok": "13385",
        "ko": "47393"
    },
    "percentiles4": {
        "total": "44299",
        "ok": "32574",
        "ko": "60000"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 9100,
        "percentage": 61
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 782,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4026,
        "percentage": 27
    },
    "group4": {
        "name": "failed",
        "count": 1092,
        "percentage": 7
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "49.145",
        "ko": "3.859"
    }
}
    },"req_calendar-image--874a2": {
        type: "REQUEST",
        name: "calendar image Redirect 1",
path: "calendar image Redirect 1",
pathFormatted: "req_calendar-image--874a2",
stats: {
    "name": "calendar image Redirect 1",
    "numberOfRequests": {
        "total": "13908",
        "ok": "5972",
        "ko": "7936"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "77",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60051",
        "ok": "52860",
        "ko": "60051"
    },
    "meanResponseTime": {
        "total": "4612",
        "ok": "1367",
        "ko": "7053"
    },
    "standardDeviation": {
        "total": "6458",
        "ok": "3875",
        "ko": "6922"
    },
    "percentiles1": {
        "total": "477",
        "ok": "312",
        "ko": "10001"
    },
    "percentiles2": {
        "total": "10091",
        "ok": "730",
        "ko": "11043"
    },
    "percentiles3": {
        "total": "12726",
        "ok": "6557",
        "ko": "13073"
    },
    "percentiles4": {
        "total": "17326",
        "ok": "18591",
        "ko": "17160"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4530,
        "percentage": 33
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 277,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1165,
        "percentage": 8
    },
    "group4": {
        "name": "failed",
        "count": 7936,
        "percentage": 57
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "49.145",
        "ok": "21.102",
        "ko": "28.042"
    }
}
    },"req_flama-medium-tt-133a4": {
        type: "REQUEST",
        name: "Flama-Medium.ttf",
path: "Flama-Medium.ttf",
pathFormatted: "req_flama-medium-tt-133a4",
stats: {
    "name": "Flama-Medium.ttf",
    "numberOfRequests": {
        "total": "15000",
        "ok": "14497",
        "ko": "503"
    },
    "minResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "10177"
    },
    "maxResponseTime": {
        "total": "60010",
        "ok": "57940",
        "ko": "60010"
    },
    "meanResponseTime": {
        "total": "2480",
        "ok": "1468",
        "ko": "31648"
    },
    "standardDeviation": {
        "total": "7305",
        "ok": "4105",
        "ko": "15012"
    },
    "percentiles1": {
        "total": "270",
        "ok": "242",
        "ko": "40002"
    },
    "percentiles2": {
        "total": "1304",
        "ok": "1085",
        "ko": "40183"
    },
    "percentiles3": {
        "total": "11463",
        "ok": "4417",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "40179",
        "ok": "23424",
        "ko": "60001"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 10333,
        "percentage": 69
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 762,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3402,
        "percentage": 23
    },
    "group4": {
        "name": "failed",
        "count": 503,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "53.004",
        "ok": "51.226",
        "ko": "1.777"
    }
}
    },"req_flama-medium-tt-174b8": {
        type: "REQUEST",
        name: "Flama-Medium.ttf Redirect 1",
path: "Flama-Medium.ttf Redirect 1",
pathFormatted: "req_flama-medium-tt-174b8",
stats: {
    "name": "Flama-Medium.ttf Redirect 1",
    "numberOfRequests": {
        "total": "14497",
        "ok": "6372",
        "ko": "8125"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "79",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "62922",
        "ok": "59922",
        "ko": "62922"
    },
    "meanResponseTime": {
        "total": "8068",
        "ok": "5747",
        "ko": "9889"
    },
    "standardDeviation": {
        "total": "14298",
        "ok": "10157",
        "ko": "16622"
    },
    "percentiles1": {
        "total": "2073",
        "ok": "2018",
        "ko": "10000"
    },
    "percentiles2": {
        "total": "10121",
        "ok": "5098",
        "ko": "10417"
    },
    "percentiles3": {
        "total": "59792",
        "ok": "32347",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "49627",
        "ko": "60003"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1607,
        "percentage": 11
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 588,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4177,
        "percentage": 29
    },
    "group4": {
        "name": "failed",
        "count": 8125,
        "percentage": 56
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "51.226",
        "ok": "22.516",
        "ko": "28.71"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
